package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Servicio de accesibilidad: aquí vive el "motor de clicks".
 *
 * Antes solo disparaba UN tap fijo en (500,500) con una duración de gesto de 10ms
 * (demasiado corta para registrarse como toque en muchas apps/versiones de Android)
 * cada vez que se pulsaba el botón del overlay. No existía bucle ni posibilidad de
 * elegir el punto de destino.
 *
 * Ahora: recibe START/STOP con coordenadas e intervalo, y mantiene un bucle con
 * Handler.postDelayed que repite el gesto hasta que llega STOP.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_START = "com.example.autoclicker.ACTION_START"
        const val ACTION_STOP = "com.example.autoclicker.ACTION_STOP"
        // Actualiza coordenadas/intervalo SIN reiniciar el bucle: se usa mientras
        // se arrastra el panel o se cambia el intervalo con el motor ya activo,
        // para no generar taps extra fuera de ritmo.
        const val ACTION_UPDATE_TARGET = "com.example.autoclicker.ACTION_UPDATE_TARGET"
        private const val MIN_INTERVAL_MS = 50L
        private const val GESTURE_DURATION_MS = 40L // antes 10ms: poco fiable en varias apps
    }

    private val handler = Handler(Looper.getMainLooper())
    private var clickRunnable: Runnable? = null

    private var targetX = 500f
    private var targetY = 500f
    private var intervalMs = 1000L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_START -> {
                    targetX = intent.getFloatExtra("x", targetX)
                    targetY = intent.getFloatExtra("y", targetY)
                    intervalMs = intent.getLongExtra("interval", intervalMs)
                        .coerceAtLeast(MIN_INTERVAL_MS)
                    startClickLoop()
                }
                ACTION_UPDATE_TARGET -> {
                    // Solo pisa los campos leídos por el runnable en marcha; el
                    // bucle ya programado (postDelayed) no se cancela ni se repite.
                    targetX = intent.getFloatExtra("x", targetX)
                    targetY = intent.getFloatExtra("y", targetY)
                    intervalMs = intent.getLongExtra("interval", intervalMs)
                        .coerceAtLeast(MIN_INTERVAL_MS)
                }
                ACTION_STOP -> stopClickLoop()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(ACTION_START)
            addAction(ACTION_UPDATE_TARGET)
            addAction(ACTION_STOP)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, filter)
        }
    }

    private fun startClickLoop() {
        stopClickLoop() // evita bucles duplicados si llega otro START mientras corre
        clickRunnable = object : Runnable {
            override fun run() {
                performTap(targetX, targetY)
                handler.postDelayed(this, intervalMs)
            }
        }
        handler.post(clickRunnable!!)
    }

    private fun stopClickLoop() {
        clickRunnable?.let { handler.removeCallbacks(it) }
        clickRunnable = null
    }

    private fun performTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, GESTURE_DURATION_MS)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClickLoop()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopClickLoop()
        unregisterReceiver(receiver)
    }
}
