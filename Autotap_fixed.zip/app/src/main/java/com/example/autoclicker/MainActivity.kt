package com.example.autoclicker

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply {
            setPadding(32, 32, 32, 16)
        }

        val button = Button(this).apply {
            text = "INICIAR OVERLAY Y SERVICIO"
            setOnClickListener {
                when {
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity) -> {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(intent)
                        Toast.makeText(this@MainActivity, "Concede el permiso de superposición y vuelve a pulsar", Toast.LENGTH_LONG).show()
                    }
                    !isAccessibilityServiceEnabled() -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        Toast.makeText(this@MainActivity, "Activa \"AutoClicker Fix\" en Accesibilidad y vuelve", Toast.LENGTH_LONG).show()
                    }
                    else -> {
                        startService(Intent(this@MainActivity, OverlayService::class.java))
                        Toast.makeText(this@MainActivity, "Panel flotante iniciado", Toast.LENGTH_SHORT).show()
                    }
                }
                refreshStatus(status)
            }
        }

        refreshStatus(status)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(button)
        }
        setContentView(layout)
    }

    private fun refreshStatus(status: TextView) {
        val overlayOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityServiceEnabled()
        status.text = buildString {
            append(if (overlayOk) "✅ Permiso de superposición\n" else "❌ Falta permiso de superposición\n")
            append(if (accessibilityOk) "✅ Servicio de accesibilidad activo" else "❌ Servicio de accesibilidad inactivo")
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/${TapAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponent, ignoreCase = true)) return true
        }
        return false
    }
}
