package com.example.autoclicker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

/**
 * Dos ventanas overlay independientes, para que el panel de control y el juego
 * de fondo estén SIEMPRE disponibles a la vez:
 *
 * 1) `panel` (TOCABLE): cabecera para arrastrar + botón de intervalo + Iniciar/Detener.
 *    Pequeño (WRAP_CONTENT) y solo intercepta toques dentro de su propio rectángulo.
 *
 * 2) `markerView` (NO TOCABLE, FLAG_NOT_TOUCHABLE): el círculo que marca el punto
 *    exacto donde se hará el auto-click. Al llevar FLAG_NOT_TOUCHABLE, esta ventana
 *    NUNCA intercepta un toque -ni los del usuario ni los que genera el propio
 *    motor de clicks-, así que tanto tus toques manuales como los gestos sintéticos
 *    de TapAccessibilityService atraviesan el marcador y llegan siempre al juego.
 *
 * Antes solo existía el panel, y el punto de click se calculaba "a ojo" 40px por
 * debajo de él sin ninguna garantía real; si el panel cambiaba de tamaño, el propio
 * overlay podía terminar robándose su propio toque.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager

    private lateinit var panel: LinearLayout
    private lateinit var headerBar: TextView
    private lateinit var intervalButton: TextView
    private lateinit var startStopButton: TextView
    private lateinit var panelParams: WindowManager.LayoutParams

    private lateinit var markerView: View
    private lateinit var markerParams: WindowManager.LayoutParams
    private var markerSizePx = 0
    private var markerGapPx = 0

    private val intervals = longArrayOf(100L, 250L, 500L, 1000L, 2000L)
    private var intervalIndex = 3 // 1000ms por defecto
    private var isRunning = false

    companion object {
        private const val CHANNEL_ID = "autoclicker_overlay_channel"
        private const val NOTIFICATION_ID = 1
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        buildMarker()
        buildPanel()
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "AutoClicker Fix", NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AutoClicker Fix activo")
            .setContentText("Panel y marcador en ejecución")
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ---------- Marcador (visual, no tocable) ----------

    private fun buildMarker() {
        val density = resources.displayMetrics.density
        markerSizePx = (28 * density).toInt()
        markerGapPx = (14 * density).toInt()

        markerView = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#552196F3"))
                setStroke((2 * density).toInt(), Color.parseColor("#2196F3"))
            }
        }

        markerParams = WindowManager.LayoutParams(
            markerSizePx, markerSizePx,
            overlayType(),
            // Clave: FLAG_NOT_TOUCHABLE => esta ventana nunca recibe toques,
            // ni reales ni sintéticos. Todo lo que "toque" este punto pasa
            // directo al juego de debajo.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 140
            y = 460 // valor inicial razonable; se recoloca tras medir el panel
        }

        windowManager.addView(markerView, markerParams)
    }

    // ---------- Panel de control (tocable) ----------

    private fun buildPanel() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#CC222222"))
            setPadding(16, 16, 16, 16)
        }

        headerBar = TextView(this).apply {
            text = "⠿ AutoClicker Fix (arrastra)"
            setTextColor(Color.WHITE)
            setPadding(24, 12, 24, 12)
        }

        intervalButton = TextView(this).apply {
            text = "🎯 ${intervals[intervalIndex]}ms"
            setTextColor(Color.WHITE)
            setPadding(24, 16, 24, 16)
            setBackgroundColor(Color.DKGRAY)
        }

        startStopButton = TextView(this).apply {
            text = "▶ INICIAR"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2E7D32"))
            setPadding(24, 16, 24, 16)
        }

        panel.addView(headerBar)
        panel.addView(intervalButton)
        panel.addView(startStopButton)

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        setupHeaderDrag()
        setupIntervalCycle()
        setupStartStopToggle()

        windowManager.addView(panel, panelParams)
        // Esperamos a que el panel tenga tamaño real medido antes de colocar el marcador.
        panel.post { updateMarkerPosition() }
    }

    private fun setupHeaderDrag() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        headerBar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = panelParams.x
                    initialY = panelParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    panelParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(panel, panelParams)
                    // updateMarkerPosition() reposiciona el marcador y, si el motor
                    // está activo, ya avisa por sí sola con sendUpdateTarget() -solo
                    // actualiza coordenadas para el SIGUIENTE tick, sin reiniciar el
                    // bucle- así que no hace falta duplicar el aviso aquí (antes esto
                    // provocaba una ráfaga de taps al mover el panel).
                    updateMarkerPosition()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupIntervalCycle() {
        intervalButton.setOnClickListener {
            intervalIndex = (intervalIndex + 1) % intervals.size
            intervalButton.text = "🎯 ${intervals[intervalIndex]}ms"
            if (isRunning) sendUpdateTarget()
        }
    }

    private fun setupStartStopToggle() {
        startStopButton.setOnClickListener {
            isRunning = !isRunning
            if (isRunning) {
                startStopButton.text = "⏸ DETENER"
                startStopButton.setBackgroundColor(Color.parseColor("#C62828"))
                sendStart()
            } else {
                startStopButton.text = "▶ INICIAR"
                startStopButton.setBackgroundColor(Color.parseColor("#2E7D32"))
                sendStop()
            }
        }
    }

    /** Recoloca el marcador justo debajo del panel, centrado con él. */
    private fun updateMarkerPosition() {
        if (!::markerParams.isInitialized || panel.width == 0) return
        markerParams.x = panelParams.x + panel.width / 2 - markerSizePx / 2
        markerParams.y = panelParams.y + panel.height + markerGapPx
        windowManager.updateViewLayout(markerView, markerParams)
        if (isRunning) sendUpdateTarget()
    }

    private fun targetPoint(): Pair<Float, Float> =
        Pair(markerParams.x + markerSizePx / 2f, markerParams.y + markerSizePx / 2f)

    private fun sendStart() {
        val (x, y) = targetPoint()
        val intent = Intent(TapAccessibilityService.ACTION_START).apply {
            setPackage(packageName)
            putExtra("x", x)
            putExtra("y", y)
            putExtra("interval", intervals[intervalIndex])
        }
        sendBroadcast(intent)
    }

    private fun sendUpdateTarget() {
        val (x, y) = targetPoint()
        val intent = Intent(TapAccessibilityService.ACTION_UPDATE_TARGET).apply {
            setPackage(packageName)
            putExtra("x", x)
            putExtra("y", y)
            putExtra("interval", intervals[intervalIndex])
        }
        sendBroadcast(intent)
    }

    private fun sendStop() {
        val intent = Intent(TapAccessibilityService.ACTION_STOP).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        sendStop()
        if (::panel.isInitialized) windowManager.removeView(panel)
        if (::markerView.isInitialized) windowManager.removeView(markerView)
    }
}
